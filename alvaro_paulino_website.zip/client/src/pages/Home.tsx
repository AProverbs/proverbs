import { Button } from "@/components/ui/button";
import { Mail, Phone, MapPin, BookOpen, Mic2, FileCheck, Languages } from "lucide-react";
import { useState } from "react";

/**
 * Design Philosophy: Minimalismo Corporativo Elegante
 * - Paleta: Azul Petróleo (#0B242A), Laranja/Dourado (#D27C2C), Branco (#FFFFFF)
 * - Tipografia: Playfair Display (títulos) + Inter (corpo)
 * - Layout: Navegação minimalista, seções alternadas azul/branco, whitespace generoso
 * - Animações: Transições suaves, scale em cards, underline animado
 */

export default function Home() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  const handleFormChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    setFormData({ name: "", email: "", message: "" });
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white border-b border-gray-100 shadow-sm">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">AP</span>
            </div>
            <span className="font-bold text-primary text-lg hidden sm:inline">
              Álvaro Paulino
            </span>
          </div>
          <div className="flex items-center gap-6">
            <a href="#services" className="text-foreground hover:text-accent transition-colors">
              Serviços
            </a>
            <a href="#about" className="text-foreground hover:text-accent transition-colors">
              Sobre
            </a>
            <a href="#contact" className="text-foreground hover:text-accent transition-colors">
              Contacto
            </a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative bg-primary text-white overflow-hidden">
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `url('https://d2xsxph8kpxj0f.cloudfront.net/310519663686179978/koZ3iyPTieuVNUi3q42JDU/hero-banner-alvaro-RxJSRjfj7Chtpi5ic8tMCT.webp')`,
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />
        <div className="container relative z-10 py-20 md:py-32">
          <div className="max-w-2xl animate-fade-in-up">
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              Álvaro Paulino Chimbungule
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 mb-4">
              Professor & Consultor Linguístico
            </p>
            <p className="text-lg text-gray-300 mb-8">
              Tradutor, Intérprete & Revisor
            </p>
            <div className="flex gap-4">
              <Button
                className="bg-accent hover:bg-accent/90 text-white px-8 py-3 rounded-lg font-semibold"
                onClick={() => document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })}
              >
                Contacte-me
              </Button>
              <Button
                variant="outline"
                className="border-white text-white hover:bg-white/10 px-8 py-3 rounded-lg font-semibold"
                onClick={() => document.getElementById("services")?.scrollIntoView({ behavior: "smooth" })}
              >
                Ver Serviços
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="bg-white py-20 md:py-32">
        <div className="container">
          <div className="text-center mb-16">
            <div className="flex justify-center mb-4">
              <div className="h-1 w-16 bg-gradient-to-r from-accent to-accent/50" />
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-primary mb-4">
              Serviços Profissionais
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Oferecemos soluções linguísticas completas para empresas, instituições e indivíduos
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: Languages,
                title: "Tradução",
                description: "Tradução profissional de documentos, websites e conteúdo especializado",
              },
              {
                icon: Mic2,
                title: "Interpretação",
                description: "Serviços de interpretação consecutiva e simultânea em múltiplas línguas",
              },
              {
                icon: FileCheck,
                title: "Revisão",
                description: "Revisão linguística e correção de textos para máxima qualidade",
              },
              {
                icon: BookOpen,
                title: "Consultoria",
                description: "Consultoria linguística e assessoria em projetos de comunicação",
              },
            ].map((service, index) => (
              <div
                key={index}
                className="bg-white rounded-lg p-6 shadow-sm hover:shadow-lg transition-all duration-300 border border-gray-100 hover:border-accent"
              >
                <service.icon className="w-12 h-12 text-accent mb-4" />
                <h3 className="text-xl font-bold text-primary mb-3">{service.title}</h3>
                <p className="text-gray-600">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="bg-primary text-white py-20 md:py-32">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex mb-4">
                <div className="h-1 w-16 bg-accent" />
              </div>
              <h2 className="text-4xl md:text-5xl font-bold mb-6">Sobre Mim</h2>
              <p className="text-lg text-gray-200 mb-4">
                Com mais de uma década de experiência em consultoria linguística, tradução e interpretação,
                dedico-me a fornecer soluções de comunicação de alta qualidade.
              </p>
              <p className="text-lg text-gray-200 mb-6">
                Minha abordagem combina rigor académico com compreensão prática das necessidades do mercado,
                garantindo que cada projeto seja executado com excelência e atenção aos detalhes.
              </p>
              <div className="space-y-4">
                <div className="flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-accent flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-primary text-sm font-bold">✓</span>
                  </div>
                  <p className="text-gray-200">Especialista em tradução técnica e legal</p>
                </div>
                <div className="flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-accent flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-primary text-sm font-bold">✓</span>
                  </div>
                  <p className="text-gray-200">Fluente em múltiplas línguas</p>
                </div>
                <div className="flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-accent flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-primary text-sm font-bold">✓</span>
                  </div>
                  <p className="text-gray-200">Experiência em consultoria empresarial</p>
                </div>
              </div>
            </div>
            <div className="relative">
              <div
                className="w-full h-96 rounded-lg overflow-hidden shadow-2xl"
                style={{
                  backgroundImage: `url('https://d2xsxph8kpxj0f.cloudfront.net/310519663686179978/koZ3iyPTieuVNUi3q42JDU/about-section-image-4iW6dwUVGR4MxmuYAb5isT.webp')`,
                  backgroundSize: "cover",
                  backgroundPosition: "center",
                }}
              />
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="bg-white py-20 md:py-32">
        <div className="container">
          <div className="text-center mb-16">
            <div className="flex justify-center mb-4">
              <div className="h-1 w-16 bg-gradient-to-r from-accent to-accent/50" />
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-primary mb-4">
              Testemunhos
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: "João Silva",
                company: "Tech Startup",
                text: "Profissionalismo excepcional. A tradução foi perfeita e entregue no prazo.",
              },
              {
                name: "Maria Santos",
                company: "Empresa de Consultoria",
                text: "Excelente qualidade de interpretação. Muito atento aos detalhes culturais.",
              },
              {
                name: "Carlos Oliveira",
                company: "Universidade",
                text: "Consultoria linguística impecável. Recomendo vivamente os serviços.",
              },
            ].map((testimonial, index) => (
              <div
                key={index}
                className="bg-gray-50 rounded-lg p-8 border border-gray-100 hover:border-accent transition-colors"
              >
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <span key={i} className="text-accent text-lg">
                      ★
                    </span>
                  ))}
                </div>
                <p className="text-gray-700 mb-6 italic">"{testimonial.text}"</p>
                <div>
                  <p className="font-bold text-primary">{testimonial.name}</p>
                  <p className="text-sm text-gray-600">{testimonial.company}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="bg-primary text-white py-20 md:py-32">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <div className="flex mb-4">
                <div className="h-1 w-16 bg-accent" />
              </div>
              <h2 className="text-4xl md:text-5xl font-bold mb-8">Contacte-me</h2>

              <div className="space-y-6">
                <div className="flex gap-4">
                  <Mail className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                  <div>
                    <p className="font-semibold mb-1">Email</p>
                    <a href="mailto:alvaro@example.com" className="text-gray-200 hover:text-accent transition-colors">
                      alvaro.paulino@example.com
                    </a>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Phone className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                  <div>
                    <p className="font-semibold mb-1">Telefone</p>
                    <a href="tel:+351912345678" className="text-gray-200 hover:text-accent transition-colors">
                      +351 912 345 678
                    </a>
                  </div>
                </div>

                <div className="flex gap-4">
                  <MapPin className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                  <div>
                    <p className="font-semibold mb-1">Localização</p>
                    <p className="text-gray-200">Lisboa, Portugal</p>
                  </div>
                </div>
              </div>
            </div>

            <form onSubmit={handleFormSubmit} className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-semibold mb-2">
                  Nome
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleFormChange}
                  className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-300 focus:outline-none focus:border-accent transition-colors"
                  placeholder="Seu nome"
                  required
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-semibold mb-2">
                  Email
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleFormChange}
                  className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-300 focus:outline-none focus:border-accent transition-colors"
                  placeholder="seu@email.com"
                  required
                />
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-semibold mb-2">
                  Mensagem
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleFormChange}
                  rows={4}
                  className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-300 focus:outline-none focus:border-accent transition-colors resize-none"
                  placeholder="Sua mensagem..."
                  required
                />
              </div>

              <Button
                type="submit"
                className="w-full bg-accent hover:bg-accent/90 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
              >
                Enviar Mensagem
              </Button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-8">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <p>&copy; 2026 Álvaro Paulino Chimbungule. Todos os direitos reservados.</p>
            <div className="flex gap-6 mt-4 md:mt-0">
              <a href="#" className="hover:text-accent transition-colors">
                LinkedIn
              </a>
              <a href="#" className="hover:text-accent transition-colors">
                Email
              </a>
              <a href="#" className="hover:text-accent transition-colors">
                Contacto
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
